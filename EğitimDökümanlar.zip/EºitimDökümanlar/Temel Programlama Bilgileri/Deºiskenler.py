isim = "Ömer Hamid"
soyisim = "Kamışlı"
yas = 21
besyilsonrakiyas = yas + 5

print(isim,soyisim,yas,besyilsonrakiyas)
sayi1 = 956
sayi2 = 0.56
sayi3 = "36"

print("sayi1/sayi2 =",sayi1/sayi2)
print("sayi1*sayi2 =",sayi1*sayi2)
print("sayi1+sayi2 =",sayi1+sayi2)
print("sayi1-sayi2 =",sayi1-sayi2)
print("sayi1-sayi2/sayi3 =",sayi1-sayi2/sayi3)

YASAKLI İFADELER

False	class	finally	is	return
None	continue	for	lambda	try
True	def	from	nonlocal	while
and	del	global	not	with
as	elif	if	or	yield
assert	else	import	pass
break	except	in	raise
