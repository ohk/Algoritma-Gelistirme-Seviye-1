print("Merhaba Dünya")
print(type("255"))
print(type(255))
print(type(0.5))
print(type("0.5"))

print(type(255+0.5))
print(type("255+0.5"))
print(type("255"+"0.5"))
