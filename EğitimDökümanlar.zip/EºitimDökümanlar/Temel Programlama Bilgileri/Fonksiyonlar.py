def FonksiyonAd():
    print("Bu bir fonksiyon örneğidir.")

def FonksTopla(x,y):
    return x+y

FonksTopla(1,2)
print("\n Bu ara satır üstte 1,2 toplaması lazım")
print(FonksTopla(1,2))
