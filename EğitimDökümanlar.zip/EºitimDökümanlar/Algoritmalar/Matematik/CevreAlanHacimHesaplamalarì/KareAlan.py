kenar=float(input("Lütfen karenin kenar uzunluğunu giriniz: "))
alan= kenar*kenar
print("Kenar uzunluğu {} olan karenin alanı = {}".format(kenar,alan))
