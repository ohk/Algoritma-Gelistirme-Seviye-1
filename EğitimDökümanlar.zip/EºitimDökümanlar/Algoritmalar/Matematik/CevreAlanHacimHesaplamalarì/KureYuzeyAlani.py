import math
yaricap = float (input("Kürenin yarıçap uzunluğunu giriniz: "))
alan = 4*math.pi*yaricap*yaricap
print("Yarıçapı {} kürenin yüzey alanı = {}".format(yaricap,alan))
