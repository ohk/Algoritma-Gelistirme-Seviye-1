kenar1 = float (input("İlk kenarın uzunluğunu giriniz: "))
kenar2 = float (input("İkinci kenarın uzunluğunu giriniz: "))
kenar3 = float (input("Üçüncü kenarın uzunluğunu giriniz: "))
cevre=kenar1+kenar2+kenar3
print("Kenar uzunlukları {},{},{} olan üçgenin çevresi = {}".format(kenar1,kenar2,kenar3,cevre))
