import math
yaricap = float (input("çemberin yarıçap uzunluğunu giriniz: "))
cevre = 2*math.pi*yaricap
cevre2 = round(cevre,5)
print("Yarıcapı {} olan çemberin çevresi = {}".format(yaricap,cevre))
print("Yarıcapı {} olan çemberin çevresi = {}".format(yaricap,cevre2))
