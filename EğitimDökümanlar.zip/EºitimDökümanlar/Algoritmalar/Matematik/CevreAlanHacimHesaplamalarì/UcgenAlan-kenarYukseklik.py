kenaruzunlugu = float (input("Kenar uzunluğunu giriniz: "))
yukseklik = float (input("Yüksekliği giriniz: "))
alan = kenaruzunlugu * yukseklik/2
print("Kenar uzunluğu {} ve yüksekliği {} olan üçgenin alanı = {} cm2".format(kenaruzunlugu,yukseklik,alan))
